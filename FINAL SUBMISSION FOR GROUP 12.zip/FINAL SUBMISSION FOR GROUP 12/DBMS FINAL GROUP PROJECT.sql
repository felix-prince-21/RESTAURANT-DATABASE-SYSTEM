#*************************************************TASK 2.2**************************************************#
DROP SCHEMA IF exists groupwork;
CREATE SCHEMA groupwork;
Use groupwork;

-- -----------------------------------------------------
-- Table `groupwork`.`Customer`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Customer`(
                           CustomerID INT AUTO_INCREMENT,
                           PRIMARY KEY (CustomerID),
                           Name VARCHAR(20),
                           CustomerType ENUM('regular', 'ocassional', 'seasonal') NULL DEFAULT NULL,
                           Phone INT(10) UNSIGNED UNIQUE,
                           email VARCHAR(40) UNIQUE);

-- -----------------------------------------------------
-- Table `groupwork`.`Staff`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Staff`(
                        StaffID INT AUTO_INCREMENT ,
                        PRIMARY KEY (StaffID),
                        FirstName VARCHAR(20),
                        LastName VARCHAR(20),
                        City VARCHAR(20),
                        Phone INT(10)UNSIGNED UNIQUE,
                        Street VARCHAR(20),
                        JobTitle VARCHAR(20),
                        DOB DATE NULL DEFAULT NULL,
                        Salary INT UNSIGNED,
                        JoinedDate datetime,
                        Email VARCHAR(20) UNIQUE);
-- -----------------------------------------------------
-- Table `groupwork`.`Manager`
-- -----------------------------------------------------                        
CREATE TABLE `groupwork`.`Manager`(
  StaffID INT,
  Department VARCHAR(20) NULL DEFAULT NULL,
  INDEX `m_fk_idx` (`StaffID` ASC),
  CONSTRAINT `m_fk`
    FOREIGN KEY (`StaffID`)
    REFERENCES `groupwork`.`Staff` (`StaffID`)
    ON UPDATE CASCADE);                        
                        
-- -----------------------------------------------------
-- Table `groupwork`.`NextOfkin`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`NextOfKin`(
                       StaffID INT,
                       FullName VARCHAR(20) NOT NULL,
                       Relationship VARCHAR(20) NOT NULL,
                       City VARCHAR(20) NOT NULL,
                       Phone INT(10) UNSIGNED NOT NULL UNIQUE,
                       Street VARCHAR(20) NOT NULL,
                       FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) on DELETE CASCADE on update CASCADE);

-- -----------------------------------------------------
-- Table `groupwork`.`Order`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Orders`(
                          OrderID INT AUTO_INCREMENT,
                          PRIMARY KEY (OrderID),
                          CustomerID INT,
                          StaffID INT, 
                          Date_Ordered date NOT NULL,
                          Present_Time time NOT NULL,
                          IsReserved boolean NOT NULL,
                          Paid bool,
                          FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) on DELETE CASCADE on update CASCADE,
                          FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID) on DELETE CASCADE on update CASCADE);
                          
-- -----------------------------------------------------
-- Table `groupwork`.`CashReceipt`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`CashReceipt`(
                         ReceiptID INT AUTO_INCREMENT,
                         PRIMARY KEY (ReceiptID),
                         OrderID INT,
                         Payment_Type VARCHAR(20) NOT NULL,
                         Present_Date date  NOT NULL,
                         Present_Time time NOT NULL,
                         `Total_Amount` INT UNSIGNED NOT NULL,
                         FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) on DELETE CASCADE on update CASCADE);

-- -----------------------------------------------------
-- Table `groupwork`.`Oderline`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Orderline`(
                         OrderID INT,
                         CONSTRAINT `ord_fk`
                         FOREIGN KEY (OrderID) REFERENCES `Orders`(OrderID) on DELETE CASCADE on update CASCADE,
                         Quantity INT UNSIGNED);

-- -----------------------------------------------------
-- Table `groupwork`.`Meal`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Meal`(
                         MealID INT AUTO_INCREMENT,
                         PRIMARY KEY (MealID),
                         Name VARCHAR(20) NOT NULL,
                         Description VARCHAR(20) NOT NULL,
                         Unit_Price INT UNSIGNED NOT NULL,
                         Size VARCHAR(20) NOT NULL,
                         IsAvailable Boolean NOT NULL);
											
-- -----------------------------------------------------
-- Table `groupwork`.`Recipe_Direction`
-- -----------------------------------------------------                         
CREATE TABLE `groupwork`.`Recipe_Direction`(
                      RecipeID INT AUTO_INCREMENT,
                      PRIMARY KEY (RecipeID),
                      Portions INT UNSIGNED NOT NULL,
                      Directions VARCHAR(100)NOT NULL,
                      UnitOfMeasure INT UNSIGNED NOT NULL);

-- -----------------------------------------------------
-- Table `groupwork`.`Recipe`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Recipe`(
                                    RecipeID INT,
                                    FOREIGN KEY (RecipeID) REFERENCES Recipe_Direction(RecipeID) on DELETE CASCADE on update CASCADE,
                                    Quantity INT UNSIGNED);
														
-- -----------------------------------------------------
-- Table `groupwork`.`Supplier`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Supplier`(
                          SupplierID INT(20) AUTO_INCREMENT,
                          PRIMARY KEY (SupplierID) ,
                          Supplier_Name VARCHAR(40) NOT NULL,
                          Quantity_Reserved INT UNSIGNED NOT NULL,
                          Item_Price DECIMAL NOT NULL); 
                          
-- -----------------------------------------------------
-- Table `groupwork`.`Inventory`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Inventory` (
  InventoryID INT AUTO_INCREMENT,
  SupplierID INT,
  ProductName VARCHAR(40) NULL DEFAULT NULL,
  StockDate DATE NULL DEFAULT NULL,
  ExpiryDate DATE NULL DEFAULT NULL,
  Quantity_Available INT(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`InventoryID`),
  CONSTRAINT `i_fk`
    FOREIGN KEY (`SupplierID`)
    REFERENCES `groupwork`.`Supplier` (`SupplierID`)
    ON UPDATE CASCADE);
  
-- -----------------------------------------------------
-- Table `groupwork`.`Ingredient`
-- -----------------------------------------------------
CREATE TABLE `groupwork`.`Ingredient`(
                          InventoryID INT,
                          FOREIGN KEY (InventoryID) REFERENCES Inventory(InventoryID) on DELETE CASCADE on update CASCADE,
                          Ingredient_Type VARCHAR(20)NOT NULL,
                          Quantity INT UNSIGNED NOT NULL );
                                                        
#*************************************************TASK 2.3**************************************************#

# We made this an index because, I want to also be able to search for an individual by their full name.
# We realised that the the full name of each individual is unique 
ALTER TABLE `groupwork`.`Staff` 
ADD INDEX `StaffFullName_indx` (`FirstName` ASC, `LastName` ASC);
;

# We made this an index to be able to search for the product faster by name.
ALTER TABLE `groupwork`.`Meal` 
ADD INDEX `product_indx` (`Name` ASC);
;

/*
* INPUT DATA INTO THE STAFF TABLE
*/
Insert into `Staff`(FirstName, LastName, City, Phone, Street, JobTitle, DOB, Salary, JoinedDate, Email) values
                                                              ("Dzigbordi", "Apalu","Accra",0244783410,"1 UNIVERSITY ave", "Manager",  '2001-11-01', 600, '2022-08-22', "O.twist@gmail.com"),
                                                              ("Miriam", "Adjei","Ho",0208972874,"1 UNIVERSITY ave", "Server",  '2001-07-01',500, '2022-08-22', "J.toliver@gmail.com"),
                                                              ("Bennett", "Caulley","Accra",0244783490,"1 UNIVERSITY ave", "Server",  '2000-09-01',500, '2022-08-22', "S.catwan@gmail.com"),
                                                              ("Felix", "Prince","Accra",0284783490,"1 UNIVERSITY ave", "Manager",  '1999-12-01',600, '2022-08-22', "p.catwan@gmail.com"),
                                                              ("Bijoux", "Abbew","Accra",0244783491,"1 UNIVERSITY ave", "Server",  '2001-10-01',500, '2022-08-22', "D.osei@gmail.com");
/*
* INPUT DATA INTO THE NextOfKin TABLE
*/
Insert into `NextOfKin`(StaffID, FullName, Relationship, City, Phone, Street) values
                                                              (1,"Jennifer twist","Sister","Kumasi",0244783490, "Kotuasi"),
                                                              (2,"Beckham Toliver","Brother","Ho",0244683490, "Agbetowu"),
                                                              (3,"Bonquesha Catwan","Spouse","Accra",0243783490, "Link1rd"),
                                                              (4,"Laila Hijazi","Spouse","Accra",0249783491, "Dodge"),
                                                              (5,"Kwadjo Osei","Brother","Accra",0242783490, "YaaGyasird");

/*
* INPUT DATA INTO THE Customer TABLE
*/
Insert into `Customer`(Name, CustomerType, Phone, Email) values
                                                              ("Angel Captan", 'regular', 0256734567,"angel.captan@ashesi.edu.gh"),
                                                              ("Kelvin Ampofo", 'ocassional', 0256734569, "kelvin.ampofo@ashesi.edu.gh"),
                                                              ("Nana Kofi Djan", 'seasonal', 0256734564, "nana.djan@ashesi.edu.gh"),
                                                              ("Ohenewaa", 'regular', 0256734579, "ohenewaa.hijo@ashesi.edu.gh"),
                                                              ("Kwadjo Osei", 'seasonal', 0256734562, "kwadjo.osei@ashesi.edu.gh");                           

/*
* INPUT DATA INTO THE Order TABLE
*/
Insert into `Orders`(CustomerID, Date_Ordered, Present_Time, IsReserved, Paid) values
														(2, '2022-11-16', '10:30:34', True, '1'),
                                                        (4, '2022-11-16', '12:30:34', True, '1'),
                                                        (5, '2022-11-16', '10:40:34', False, '0'),
														(1, '2022-11-16', '11:30:04', True, '1'),
														(3, '2022-11-16', '10:50:44', False, '0');

/*
* INPUT DATA INTO THE CashReceipt TABLE
*/
Insert into `CashReceipt`(OrderID, Payment_Type,Present_Date, Present_Time, Total_Amount) values
														(2, "Mobile Money",'2022-11-16', '10:30:34', 90 ),
                                                        (3, "Mobile Money",'2022-11-16', '10:30:34', 100 ),
                                                        (5, "Mobile Money",'2022-11-16', '12:30:34', 1234 ),
                                                        (1, "Mobile Money",'2022-11-16', '12:30:34', 254 ),
                                                        (1, "Cash",'2022-11-16', '10:40:34', 24),
                                                        (3, "Cash",'2022-11-16', '10:40:34', 16),
														(5, "Cash",'2022-11-16', '11:30:04', 82 ),
                                                        (2, "Cash",'2022-11-16', '11:30:04', 55 ),
														(1, "Mobile Money",'2022-11-16', '10:50:44', 34),
                                                        (2, "Mobile Money",'2022-11-16', '10:50:44', 15);

/*
* INPUT DATA INTO THE Orderline TABLE
*/
Insert into `Orderline`(Quantity) values
							(1),
                            (5),
                            (8),
                            (2),
                            (4),
                            (6),
                            (2),
                            (1),
                            (9),
                            (6);
  
  /*
* INPUT DATA INTO THE Meal TABLE
*/
Insert into `Meal`(Name, Description, Unit_Price, Size, IsAvailable) values
														("Burger", "Fuego", 35, "Double-Decker", True),
                                                        ("Shawarma", "Beef", 25, "Large", True),
                                                        ("Cake", "Mud Cake", 80, "Bento", False),
														("Hot Dog", "Loaded", 20, "Large", True),
														("Fries", "Salted", 12, "Medium", False);

/*
* INPUT DATA INTO THE Recipe_Direction TABLE
*/
Insert into `Recipe_Direction`(Portions, Directions, UnitOfMeasure) values
														(1, "Cut Bread, Spread sauce, place burger patty, add cheese,add egg, place veggies", 1),
                                                        (1, "Break bread into 2, spread sauce, place cabbage, add veggies, add beef", 1),
                                                        (1, "place parchment paper in box, place cake in box", 1),
														(1, "cut bread, place wiener in bread, pour sauce, pour veggies, add cheese,add egg", 1),
														(1, "fill cup with one portion fries", 1);

/*
* INPUT DATA INTO THE Recipe TABLE
*/                                                        
Insert into `Recipe`(Quantity) values
							(1),
                            (5),
                            (8),
                            (2),
                            (4),
                            (6),
                            (2),
                            (1),
                            (9),
                            (6);

/*
* INPUT DATA INTO THE Supplier TABLE
*/                                                        
Insert into `Supplier`(Supplier_Name, Quantity_Reserved, Item_Price) values
														("New Horizon", 20, 5),
                                                        ("Madam Cold", 10, 7.2),
                                                        ("Dansoman Market", 50, 1.2),
                                                        ("Lapaz Market", 50, 10),
                                                        ("Osu", 20, 3.5);
/*
* INPUT DATA INTO THE Inventory TABLE
*/     
INSERT INTO `groupwork`.`Inventory`  (`SupplierID`,`ProductName`, `StockDate`, `ExpiryDate`, `Quantity_Available`) VALUES (2, 'Beef', '2019-06-24', '2023-11-12', 8),
																					   (1,'Mayo', '2019-06-24', '2023-11-12', 90),
                                                                                       (2,'Cheese', '2019-06-24', '2023-11-12', 50),
                                                                                       (3,'Tissue', '2019-06-24', '2023-11-12', 20),
                                                                                       (4,'Onions', '2019-06-24', '2023-11-12', 30),
                                                                                       (5,'Containers', '2019-06-24', '2023-11-12', 27),
                                                                                       (2,'Stickers', '2019-06-24', '2023-11-12', 31),
                                                                                       (4,'Aluminium Foil', '2019-06-24', '2023-11-12', 120),
                                                                                       (3, 'Cling film', '2019-06-24', '2023-11-12', 199);  

/*
* INPUT DATA INTO THE Ingredient TABLE
*/                                                        
Insert into `Ingredient`(Ingredient_Type, Quantity) values
														("Burger Meat", 12),
                                                        ("Beef", 10),
                                                        ("Flour", 50),
                                                        ("Sugar", 30),
                                                        ("Milk", 10),
                                                        ("Cabbage", 2),
                                                        ("Fries", 3),
                                                        ("Wieners", 30),
                                                        ("Bread", 24),
                                                        ("Ketchup",3);
                                                        
INSERT INTO `groupwork`.`Manager` (`Department`) VALUES ('Sales'),
														  ('Finance'),
														  ('Inventory'),
														  ('Staff');                                                       
                                                        
#*************************************************TASK 2.4**************************************************#                                                   
#THIS IS WHERE WE TEST OUT OUR QUERIES FOR OUR TABLES

#This is a query that returns the information about the supplier and the products that each one of them supply
/*
* The manager would like to see all the suppliers and what they are contributing to the restaurant
* Also this can be used to see the supplier with the most products
*/
SELECT Supplier_Name, Quantity_Reserved, Item_Price, ProductName
FROM Supplier INNER JOIN Inventory ON Supplier.SupplierID = Inventory.SupplierID;                                                      
                      
#This is a query that returns the availability of meals
SELECT Name, Description
FROM Meal
WHERE IsAvailable = True;

#This is a query that returns whether the kitchen needs to restock
SELECT ProductName, Inventory.SupplierID
FROM Inventory
INNER JOIN Supplier
ON Inventory.SupplierID = Supplier.SupplierID
WHERE Inventory.Quantity_Available > 10;  

#This is a query that returns the mode of payment of customers
SELECT fel.Name, fel.Phone, fel.Paid, CashReceipt.Payment_Type, CashReceipt.Present_Date, CashReceipt.Total_Amount
FROM (SELECT Name, Paid, Phone, OrderID
FROM Customer LEFT JOIN Orders ON Customer.CustomerID = Orders.CustomerID) fel
INNER JOIN CashReceipt ON fel.OrderID = CashReceipt.OrderID; 






                      
                      
                                  
                                                        
                                                        
                                                        
                                                        
                                                        